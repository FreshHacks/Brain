Telegram.WebApp.ready();

const initData = Telegram.WebApp.initDataUnsafe;


function register(referrer_id){
    fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(initData, referrer_id)
    }).then(response => response.json())
      .then(data => {
            console.log('Registration result:', data);
        })
      .catch(error => console.error('Error:', error));
}
