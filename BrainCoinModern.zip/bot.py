import logging
import asyncio
from aiogram import Bot, Dispatcher, Router, types
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
import sys
from aiogram.filters import CommandStart
from aiogram.types import Message, WebAppData
import aiogram.types

TOKEN = ""

dp=Dispatcher()
router = Router()

@router.message(WebAppData)
async def web_app_data_handler(message: Message):
    web_app_data = message.web_app_data
    if web_app_data:
        logging.info(f"Получены данные из WebApp: {web_app_data.data}")

        await message.answer(f"Спасибо за отправленные данные: {web_app_data.data}")
    else:
        await message.answer("Данные не были получены.")

@dp.message(CommandStart())
async def startCommandHandler(message : Message) -> None:
    
    url = 'https://c076-91-214-136-51.ngrok-free.app'
    markup = types.InlineKeyboardMarkup(
        inline_keyboard = [
            [
                types.InlineKeyboardButton(
                    text="Start BrainTap",
                    web_app = types.WebAppInfo(url=f'{url}/?name={message.from_user.full_name}&id={message.from_user.id}'),
                )
            ]
        ]
        
        
    )
    
    await message.answer("""
    Welcome to BrainTap!

Challenge your mind, solve fun math problems, and earn points as you sharpen your brain. Get ready to tap into your full mental potential!

Let the brain-training begin!
    """, reply_markup=markup)
    

async def start() -> None:
    
    dp.include_router(router)
    bot = Bot(token=TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    
    await dp.start_polling(bot)
    
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    asyncio.run(start())