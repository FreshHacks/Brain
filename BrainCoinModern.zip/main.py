import hashlib
import hmac
import time
from database import Database as db

from flask import Flask, render_template, request, jsonify

from apscheduler.schedulers.background import BackgroundScheduler


def boostApply():
    users = db().getUsers()
    for user in users:
        boosted=user[4]
        if boosted[0]=="0":
            continue
        elif boosted[0]=="1":
            db().setBalance(user[1], user[5]+50)
        elif boosted[0]=="2":
            db().setBalance(user[1], user[5]+150)
        elif boosted[0]=="3":
            db().setBalance(user[1], user[5]+300)


scheduler = BackgroundScheduler()
scheduler.add_job(func=boostApply, trigger="interval", seconds=5)
scheduler.start()


app = Flask("Flask")

def checkAuth(data):
    auth_data = dict(sorted((k, v) for k, v in data.items() if k != 'hash'))
    check_string = '\n'.join([f'{k}={v}' for k, v in auth_data.items()])
    
    secret_key = hashlib.sha256("7421473179:AAFLbwVUFC49FidE-Xk2PkPsDDcOq4YVir0".encode()).digest()
    calculated_hash = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
    
    return calculated_hash == data['hash']


def is_auth_data_fresh(auth_date):
    current_time = int(time.time())
    return (current_time - auth_date) < 24 * 60 * 60

@app.route("/",methods=["GET", "POST"])
def main():
    return render_template("index.html", ref_id = request.args.get("tgWebAppStartParam"))


@app.route("/tasks")
def tasks():
    id = request.args.get('id')
    user = db().getUser(tgid=id)
    completedtasksid = user['tasks']

    completedtasks = []
    tasks = db().getTasks()

    for task_id in completedtasksid:
        task = db().getTaskById(task_id)
        if task:
            task_dict = {
                'id': task[0],
                'description': task[2],
                'earn': task[1],
                'url': task[3]
            }
            completedtasks.append(task_dict)

    available_tasks = [
        {
            'id': task[0],
            'description': task[2],
            'earn': task[1],
            'url': task[3]
        } for task in tasks if str(task[0]) not in map(str, completedtasksid)
    ]


    return render_template("tasks.html", tasks=available_tasks, completed=completedtasks)


@app.route("/friends")
def friends():
    frs = db().getFriends(tgid=request.args.get('id'))
    friends = []
    
    if frs != []:
        if frs:
            for f in frs:
                print(f)
                friends.append(db().getUser(f))
    
    return render_template("friends.html", friends = friends)


@app.route("/boosts")
def boosts():
    
    bsts = db().getBoosts(tgid=request.args.get('id'))
    boostsL = []
    for i in bsts:
        boostsL.append(int(i))
    
    return render_template("boost.html", boosts = boostsL)


@app.route("/register", methods=['POST'])
def register():
    data = request.json
    if db().userExist(data['user'].get('id')):
        return jsonify({'status': 'error', 'message': 'User already exists'}), 403
    
    if not is_auth_data_fresh(int(data['auth_date'])):
        return jsonify({'status': 'error', 'message': 'Auth data is too old'}), 403

    telegram_user_id = data['user']['id']
    first_name = data['user']['first_name']
    last_name = data['user'].get('last_name', '')
    referral_id = data.get('start_param')

    if referral_id and db().userExist(referral_id):
        db().insertUser(telegram_user_id, first_name + " " + last_name, referral_id)
        db().addReferral(referral_id, telegram_user_id)
        db().setBalance(telegram_user_id, 500)
        db().setBalance(referral_id, db().getUser(referral_id).get("balance")+500)
        return jsonify({'status': 'ok', 'message': 'Registered with referral'}), 200
    else:
        db().insertUser(telegram_user_id, first_name + " " + last_name, 0)
        return jsonify({'status': 'ok', 'message': 'Registered without referral'}), 200

    

@app.route('/user', methods=['GET'])
def get_user():
    user_id = request.args.get('id')

    if not user_id:
        return jsonify({'status': 'error', 'message': 'Missing parameters'}), 400

    

    return jsonify({'status': 'success', 'data': db().getUser(user_id)})


@app.route('/setbalance', methods=["POST"])
def setbalance():
    request_data = request.get_json()
    user_id = request_data.get("id")
    balance = request_data.get("bal")

    if balance is None:
        return jsonify({"error": "Balance value is required."}), 400

    user = db().getUser(user_id)
    if user is None:
        return jsonify({"error": "User not found."}), 404

    db().setBalance(int(user_id), int(balance))

    return jsonify({"message": "Balance updated successfully."}), 200


@app.route('/completetask', methods = ['GET', 'POST'])
def completetask():
    if request.method == 'POST':
        request_data = request.get_json()
        print(request_data)
        id=request_data.get("id")
        tid=request_data.get("tid")
        db().completeTask(int(id), int(tid))
        db().setBalance(int(id), db().getUser(int(id)).get("balance")+db().getTaskById(int(tid)).get("earn"))
        return "OK - 200"

    else: return "GFYS"
    

@app.route('/getbalance', methods=["GET", "POST"])
def getbalance():
    if request.method == "POST":
        request_data = request.get_json()
        user_id = request_data.get("id")
        
        balance = db().getUser(user_id).get("balance")
        
        return jsonify({"balance": balance})
    
    
@app.route('/sendmessage', methods=["GET", "POST"])
def sendmessage():
    request_data = request.json()
    id = request_data.get("id")
    message = request_data.get("message")


@app.route('/boost', methods = ['GET', 'POST'])
def boost():
    if request.method == 'POST':
        
        request_data = request.get_json()
        id=request_data.get("id")
        bid=request_data.get("bid")
        print(id, bid)
        balance = db().getUser(id).get("balance")
        if balance>db().calcPrice(id, bid):
            db().setBalance(id, db().getUser(id).get("balance")-db().calcPrice(id, bid))
            
        db().boost(int(id), int(bid))
        return jsonify({"status": "200"})

    else: return "GFYS"
        


app.run(debug=False)