import sqlite3


class Database:
    def __init__(self) -> None:
        self.db = sqlite3.connect("database.db")
        self.c = self.db.cursor()
        
    def userExist(self, tgid):
        self.c.execute("SELECT EXISTS(SELECT 1 FROM users WHERE telegram_id = ?)", (tgid,))
        return self.c.fetchone()[0] == 1

    def addReferral(self, tgid, referralid):
        before = self.c.execute("SELECT friends FROM users WHERE telegram_id = ?", (tgid,)).fetchone()[0]
        if before == None or before=="":
            self.c.execute(f"update users set friends = {str(referralid)} where telegram_id = {tgid}")
            
        else:
            if not str(referralid) in self.friends(before):
                self.c.execute("UPDATE users SET friends = ? WHERE telegram_id = ?", (before+','+str(referralid), tgid))
            
        self.db.commit()
    
    def insertUser(self, tgid, name, referral_id):
        self.c.execute("INSERT INTO users (telegram_id, name, referrer_id, boosts, balance) VALUES (?, ?, ?, ?, 0)", (tgid, name, referral_id, "0,0"))
        
        self.db.commit()
        
    def setBalance(self, tgid, bal:int):
        self.c.execute("UPDATE users SET balance = ? WHERE telegram_id = ?", (bal, tgid))
        self.db.commit()
        
        
    def getUser(self, tgid):
        tgid = int(tgid)

        rawdata = self.c.execute("SELECT * FROM users WHERE telegram_id = ?", (tgid,)).fetchone()

        print(rawdata)
        
        data = {
            "name":rawdata[2],
            "balance":rawdata[5],
            "friends":self.friends(rawdata[3]),
            "tasks":self.friends(rawdata[6]),
            "boosts":self.friends(rawdata[4]),
            "referrer_id":rawdata[7]
        }

        return data


    def friends(self, rawfriend):
        if rawfriend is None or rawfriend == "":
            return []
        
        rawfriends = ""
        for i in str(rawfriend):
            rawfriends+=i
            
        return rawfriends.split(",")


    def getFriends(self, tgid):
        return self.getUser(tgid).get('friends')
    
    def getBoosts(self, tgid):
        return self.getUser(tgid).get('boosts')
    
    def getTasks(self):
        return self.c.execute("SELECT * FROM tasks").fetchall()
    
    def getTaskById(self, id):
        id=int(id)
        data = self.getTasks()
        element = next((item for item in data if item[0] == id), None)
        return element
    
    def completeTask(self, id, tid):
        before = self.c.execute("SELECT tasks FROM users WHERE telegram_id = ?", (id,)).fetchone()[0]
        if before == None or before=="":
            self.c.execute(f"update users set tasks = {str(tid)} where telegram_id = {id}")
            
        else:
            if not str(tid) in self.tasks(before):
                self.c.execute("UPDATE users SET tasks = ? WHERE telegram_id = ?", (before+','+str(tid), id))
            
        self.db.commit()
        
    def boost(self, id, bid):
        before = self.c.execute("SELECT boosts FROM users WHERE telegram_id = ?", (id,)).fetchone()[0]
        
        if before is None or before == "":
            self.c.execute("UPDATE users SET boosts = ? WHERE telegram_id = ?", (str(bid), id))
        else:
            boosts_list = before.split(',')
            
            if str(bid) not in boosts_list:
                boosts_list.append(str(bid))
                self.c.execute("UPDATE users SET boosts = ? WHERE telegram_id = ?", (','.join(boosts_list), id))
        
        boosts_list = before.split(',')
        
        if bid == 1:
            boosts_list[0] = str(int(boosts_list[0]) + 1)
        else:
            if len(boosts_list) >= 2:
                boosts_list[1] = str(int(boosts_list[1]) + 1)
        
        self.c.execute("UPDATE users SET boosts = ? WHERE telegram_id = ?", (','.join(boosts_list), id))
        
        self.db.commit()

    
    def calcPrice(self, id, bid):
        before = self.c.execute("SELECT boosts FROM users WHERE telegram_id = ?", (id,)).fetchone()[0]
        if bid==1:
            level = int(before[0])
            return 5000+(level*3000)
        
        else:
            level = int(before[0])
            return 3000+(level*1000)
        
    def getUsers(self):
        return self.c.execute("SELECT * FROM users")