document.getElementById("name").textContent = Telegram.WebApp.initDataUnsafe.user.first_name + Telegram.WebApp.initDataUnsafe.user.last_name;
document.getElementById("frienda").href = "/friends?id=" + Telegram.WebApp.initDataUnsafe.user.id;
document.getElementById("tasksa").href = "/tasks?id=" + Telegram.WebApp.initDataUnsafe.user.id;
document.getElementById("boosta").href = "/boosts?id=" + Telegram.WebApp.initDataUnsafe.user.id;


fetch(`/user?id=${initData.user.id}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById("balance").textContent = data.data.balance + ' B';
            });